<?php

ignore_user_abort(true);

@file_put_contents('test-curl.log', date('c')." - test cURL", LOCK_EX);

sleep(1);

@file_put_contents('test-curl.log', " - end test ".date('c'), LOCK_EX | FILE_APPEND);

?>