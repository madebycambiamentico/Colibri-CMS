<?php

header('Content-Type: text/plain; charset=utf-8');


require_once "../functions.inc.php";
require_once 'async_curl.fn.php';

define('DELIVERY_URL', $CONFIG['domain'].$CONFIG['mbc_cms_dir'].'test-curl-receiver.php' );

echo date('d/m/Y H:i:s').' - testing cURL to '.DELIVERY_URL;

async_curl( DELIVERY_URL ) or die("cURL failed on link ".DELIVERY_URL);

sleep(2);

if (file_exists('test-curl.log')){
	$test = @file_get_contents('test-curl.log');
	echo "\ncURL test succesfull:\n{$test}";
	unlink('test-curl.log');
}
else{
	echo "\ncURL test failed:\nYOU NEED cURL LIBRARY ENABLED, AND SERVER TO SERVER CONNECTION ENABLED!";
}

?>