<?php

require_once("config.php");



//--------------------------------------------------------
function STOPFORDEBUG($die=true){
	global $requestedURL, $pathPieces, $mylang, $CONFIG;
	
	echo 'LANG : '.$mylang;
	
	echo '<br>a) $requestedURL:<pre>'.print_r($requestedURL,true).'</pre>';
	
	echo '<br>b) $pathPieces:<pre>'.print_r($pathPieces,true).'</pre>';
	
	echo '<br>c) $CONFIG["database"]:<pre>'.print_r($CONFIG['database'],true).'</pre>';
	echo '<br>c) $CONFIG[...]:<pre>'.
		'domain : '.print_r($CONFIG['domain'],true).'<br>'.
		'mbc_cms_dir : '.print_r($CONFIG['mbc_cms_dir'],true).'<br>'.
		'c_dir : '.print_r($CONFIG['c_dir'],true).
	'</pre>';
	
	echo '<br>d) $_SERVER:<pre>'.print_r($_SERVER,true).'</pre>';
	
	$die and die();
}
//--------------------------------------------------------

//-----------------------------------
//should be fetched from database...
$known_langs = ['it','en','de','fr'];
//should contain 2-letters or 5-letters (e.g.: "en", "en-UK")
//-----------------------------------

function setPreferredLanguage($lang='it'){
	setcookie('lang', $lang, time()+(86400*7), "/", "", false, false); // 86400 = 1 day, for all domain directory, no domain restriction, no SSL, js can edit
}

function detectPreferredLanguage(){
	global $known_langs;
	
	if (!empty($_COOKIE['lang']) && in_array($_COOKIE['lang'], $known_langs))
		return $_COOKIE['lang'];
	
	$user_pref_langs = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']);

	//set default language, in case neither one of the active ones are available.
	$lang = $known_langs[0];
	
	foreach($user_pref_langs as $idx => $lang) {
		$lang = substr($lang, 0, 2);
		if (in_array($lang, $known_langs)) {
			break;
		}
	}
	setPreferredLanguage($lang);
	return $lang;
}



//global variables
$pageid			= null;
$page				= null;
$web				= null;
$templatepath	= null;
$mylang			= detectPreferredLanguage();

//echo '<pre>'.print_r($_SERVER,true).'</pre>'; die;

//***************************************
//				redirect to page...
//***************************************
if (isset($_SERVER['REDIRECT_URL'])){
	
	if ($CONFIG['mbc_cms_dir']==='/')
		$requestedURL = substr($_SERVER['SCRIPT_URL'],1);
	else
		$requestedURL = str_ireplace($CONFIG['mbc_cms_dir'],"",$_SERVER['SCRIPT_URL']);
	$pathPieces = explode("/",$requestedURL);
	
	STOPFORDEBUG();
}

?>