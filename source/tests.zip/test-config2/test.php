<?php

require_once("config.php");

echo '<br>c) $CONFIG[...]:<pre>'.
	'__FILE__ : '.__FILE__.'<br>'.
	'domain : '.print_r($CONFIG['domain'],true).'<br>'.
	'mbc_cms_dir : '.print_r($CONFIG['mbc_cms_dir'],true).'<br>'.
	'c_dir : '.print_r($CONFIG['c_dir'],true).
'</pre>';

echo '<br>d) $_SERVER:<pre>'.print_r($_SERVER,true).'</pre>';

echo dirname('/ciao');
?>