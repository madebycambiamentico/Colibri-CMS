<?php

if (version_compare(phpversion(), '5.4.0', '<')) {
	trigger_error('You are running a version of PHP not supported (too old). Minimum requirements are <b>PHP 5.4.0</b>', E_USER_ERROR);
}


//-------------------------
function fix_script_url(){
	$script_url = NULL;
	//to do:
	//what order? SCRIPT_URL, REQUEST_URI, REDIRECT_URL?
	//to be determined... not entirely sure
	//and by the way: SCRIPT_URL is what I think it is?
	
	if (!empty($_SERVER['SCRIPT_URL']))   
		$script_url = $_SERVER['SCRIPT_URL'];
	elseif (!empty($_SERVER['REQUEST_URI'])) {
		$p = parse_url($_SERVER['REQUEST_URI']);
		$script_url = $p['path'];
	}
	elseif (!empty($_SERVER['REDIRECT_URL'])) 
		$script_url = $_SERVER['REDIRECT_URL'];
	else
		die('Cannot determine $_SERVER["SCRIPT_URL"].');

	$_SERVER['SCRIPT_URL'] = $script_url;
	return $script_url;
}
echo "SCRIPT_URL is ".(empty($_SERVER['SCRIPT_URL']) ? 'not ' : '')."available<br>";
fix_script_url();
//-------------------------




$CONFIG = [
	//------------- LOCKED VARS: DO NOT CHANGE -------------
	//domain -- example: "http://localhost:8080"
	'domain' => (((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') || $_SERVER['SERVER_PORT']==443) ? 'https://':'http://' ).$_SERVER['HTTP_HOST'],
	//absolute path for main directory -- example: "/test-cms/mbc-cms/"
	'mbc_cms_dir' => '/',
	//drive path for this file -- example: "C:/virtual-hosts/Colibri/test-cms/mbc-cms/"
	'c_dir' => str_replace("\\","/",__DIR__).'/',	//do not change!
	//----------------- END OF LOCKED VARS -----------------
	
	
	//------------- CUSTOMIZABLE VARS -------------
	//database directory and file name.
	//if you change this, please change accordingly in mbc-filemanager config file.
	'database' => [
		'dir' => 'database/',
		'name' => 'mbcsqlite3.db'
	],
	/* the next values are used to de/en-crypt emails as a failsafe if database is stolen
	* or visible for some reason (.htaccess not set properly...)
	* IF this file (config.php) can be viewed RAW, the emails will be unsecured
	* IF you change this values and the database is already populated by users,
	* all emails could no longer be decrypted and will be invalidated.
	* in this last case you should decrype and re-encrypt the mails using some sort of script.
	*/
	'encrypt' => [
		'secret_key' => 'my very secret key #666',		//change this variable to random string!
	]
	//----------- END OF CUSTOMIZABLE VARS -----------
];



//----------- find current directory url: ------------
// !!! WARNING !!! WORKS ONLY FOR FILES WITHIN INSTALLATION DIRECTORY FOLDER, NOT SUB-FOLDERS!!!
// if requested "http://www.your_site.com/[installation_directory]/required/file"
// should find something like:
//   $_SERVER['SCRIPT_NAME'] = "/[installation_directory]/index.php"
//   $_SERVER['SCRIPT_URL'] = "/[installation_directory]/required/file"
$prefix = dirname($_SERVER['SCRIPT_NAME']);  // "/wathever/index.php" -> "/wathever", or "/whatever" -> "/"
if ($prefix !== '/'){
	$prefix .= '/';
	$length = strlen($prefix);
	$item = $_SERVER['SCRIPT_URL']; // /wathever/anythingelse/boh.boh
	// check if there is a match; if not, decrease the prefix by one character at a time
	while ($length && substr($item, 0, $length)!==$prefix) {
		$length--;
		$prefix = substr($prefix, 0, -1);
	}
	if (!$length) {
		$CONFIG['mbc_cms_dir']="/";
	}
	else{
		$CONFIG['mbc_cms_dir']=$prefix;
	}
}


//set absolute database path
$CONFIG['database']['path'] = $CONFIG['c_dir'].$CONFIG['database']['dir'].$CONFIG['database']['name'];


/**
 * Autoloader for any class
 * 
 * // istead of write:
 * include_once("./php/foo.class.php");
 * include_once("./php/bar.class.php");
 * ...
 * 
 * // the right classes will be loaded automatically on call
 * // with no need to explicitly include file!!!
 * $foo = new Foo;
 * BAR::dosomething();
 */

function mbc_autoload($pClassName) {
	global $CONFIG;
	include_once $CONFIG['c_dir'].'php/' . strtolower($pClassName).'.class.php';
}
spl_autoload_register("mbc_autoload");


?>